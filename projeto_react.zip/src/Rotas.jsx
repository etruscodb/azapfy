import React from 'react'
import {Component} from 'react'


class Rotas extends Component{
constructor(){
   super()

    


}

render(){

return(

<div>
  
 
 
</div>


)

}




}


export default Rotas